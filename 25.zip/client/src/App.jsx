import './App.css';
import { Route, Routes } from 'react-router-dom';
import { createTheme } from '@mui/material';
import { ToastContainer } from 'react-toastify';
import { ThemeProvider } from '@emotion/react';

import Home from './components/landing/Home';
import Contact from './components/landing/Contact';
import About from './components/landing/About';

import CustomerRegistration from "./components/customer/CustomerRegistration"
import CustomerLogin from './components/customer/CustomerLogin';
import CustomerForgotPassword from './components/customer/CustomerForgotPassword';
import CustomerResetPassword from './components/customer/CustomerResetPassword';
import CustomerHome from './components/customer/CustomerHome';

import OrganiserRegister from './components/organiser/OrganiserRegister';
import OrganiserLogin from './components/organiser/OrganiserLogin';
import OrganiserForgotPassword from './components/organiser/OrganiserForgotPassword';
import OrganiserResetPassword from './components/organiser/OrganiserResetPassword';
import OrganiserHome from './components/organiser/OrganiserHome';

import BussinessRegister from './components/bussiness/BussinessRegister';
import BussinessLogin from './components/bussiness/BussinessLogin';
import BussinessForgotPassword from './components/bussiness/BussinessForgotPassword';
import BussinessResetPassword from './components/bussiness/BussinessResetPassword';
import BussinessHome from './components/bussiness/BussinessHome';

import AdminLogin from './components/admin/AdminLogin';
import AdminDashboard from './components/admin/AdminDashboard';

function App() {
  const theme = createTheme({
    palette: {
      primary: {
        main: '#333333',
      },
      secondary: {
        main: '#6F32BF',
      },
    },
  });

  return (
    <>
      <ToastContainer />
      <ThemeProvider theme={theme}>
        <Routes>
          {/* landing */}
          <Route path='/' element={<Home />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/about' element={<About />} />

          {/* admin */}
          <Route path='/admin/login' element={<AdminLogin />} />
          <Route path='/admin/dashboard' element={<AdminDashboard />} />

          {/* customers */}
          <Route path='/customer/registration' element={<CustomerRegistration />} />
          <Route path='/customer/login' element={<CustomerLogin />} />
          <Route path='/customer/forgotpassword' element={<CustomerForgotPassword />} />
          <Route path='/customer/resetpassword' element={<CustomerResetPassword />} />
          <Route path='/customer/home' element={<CustomerHome />} />

          {/* bussiness */}
          <Route path='/bussiness/registration' element={<BussinessRegister />} />
          <Route path='/bussiness/login' element={<BussinessLogin />} />
          <Route path='/bussiness/forgotpassword' element={<BussinessForgotPassword />} />
          <Route path='/bussiness/resetpassword' element={<BussinessResetPassword />} />
          <Route path='/bussiness/home' element={<BussinessHome />} />

          {/* organiser */}
          <Route path='/organiser/registration' element={<OrganiserRegister />} />
          <Route path='/organiser/login' element={<OrganiserLogin />} />
          <Route path='/organiser/forgotpassword' element={<OrganiserForgotPassword />} />
          <Route path='/organiser/resetpassword' element={<OrganiserResetPassword />} />
          <Route path='/organiser/home' element={<OrganiserHome />} />
        </Routes>
      </ThemeProvider>
    </>
  )
}

export default App;
