import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/tests/setup.js',
    css: true,
  },
  base: "/local_biz/",
  server: {},
  preprocessorOptions: {
    sass: {
      api: "modern-compiler",
    },
  },
  css: {
    scss: {
      api: "modern-compiler", // or "modern", "legacy"
      importers: [
        // ...
      ],
    },
  },
});