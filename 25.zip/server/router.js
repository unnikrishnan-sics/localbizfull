const express=require("express");
const router=express.Router();

const protectedRoute=require("./Middleware/protectedRoute")

const customerController=require("./Controller/customerController");
const organisationController=require("./Controller/OrganiserController");
const bussinessController=require("./Controller/bussinessController")
const adminController=require("./Controller/adminController");

//Default Route
router.get("/",(req,res)=>{
    res.send("Welcome to Local Biz API");
})

// admin
router.post("/admin/login",adminController.adminLogin)
router.post("/organisation/getAllOrgaiser",protectedRoute.protectedRoute,adminController.getAllOrgaiser);

// customer
router.post("/customer/registration",customerController.uploadProfilePic,customerController.customerRegister);
router.post("/customer/login",customerController.customerLogin);
router.post("/customer/forgotpassword", customerController.customerForgotPassword);
router.post("/customer/resetpassword", customerController.customerResetPassword);
router.get("/customer/getcustomer/:id",protectedRoute.protectedRoute,customerController.getCustomerById);
router.post("/customer/editcustomer/:id",protectedRoute.protectedRoute,customerController.uploadProfilePic,customerController.editCustomerById)

// organisation
router.post("/organisation/registration",organisationController.uploadProfilePic,organisationController.organisationRegister);
router.post("/organisation/login",organisationController.organisationLogin);
router.post("/organisation/forgotpassword", organisationController.organisationForgotPassword);
router.post("/organisation/resetpassword", organisationController.organisationResetPassword);
router.get("/organisation/getorganisation/:id",protectedRoute.protectedRoute,organisationController.getOrganisationById);
router.post("/organisation/editorganisation/:id",protectedRoute.protectedRoute,organisationController.uploadProfilePic,organisationController.editOrganisationById);

// Bussiness
router.post("/bussiness/registration",bussinessController.upload,bussinessController.bussinessRegister);
router.post("/bussiness/login",bussinessController.bussinessLogin);
router.post("/bussiness/forgotpassword", bussinessController.bussinessForgotPassword);
router.post("/bussiness/resetpassword", bussinessController.bussinessResetPassword);
router.get("/bussiness/getbussiness/:id",protectedRoute.protectedRoute,bussinessController.getBussinessById);
router.post("/bussiness/editBussiness/:id",protectedRoute.protectedRoute,bussinessController.upload,bussinessController.editBussinessById)

module.exports=router;
